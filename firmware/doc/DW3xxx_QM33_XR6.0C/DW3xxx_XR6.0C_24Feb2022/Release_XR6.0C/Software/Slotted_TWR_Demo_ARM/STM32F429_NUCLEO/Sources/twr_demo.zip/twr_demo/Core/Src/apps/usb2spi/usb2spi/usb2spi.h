/**
 * @file      usb2spi.h
 *
 * @brief     Header file for usb2spi
 *
 * @author    Decawave
 *
 * @attention Copyright 2017-2019 (c) Decawave Ltd, Dublin, Ireland.
 *            All rights reserved.
 *
 */

#ifndef __INC_USB2SPI_H_
#define __INC_USB2SPI_H_    1

#ifdef __cplusplus
 extern "C" {
#endif

#include "usb_uart_rx.h"
#include <stdint.h>
#include <error.h>

usb_data_e usb2spi_protocol_check(uint8_t *p, uint16_t len);
error_e    usb2spi_process_init(void);
void usb2spi_process_run(void);
void usb2spi_process_terminate(void);

#ifdef __cplusplus
}
#endif

#endif /* __INC_USB2SPI_H_ */
