/**
 * @file      config.c
 *
 * @brief     Supports NVM and bss configuration sections:
 *            FConfig : section in NVM, where current parameters are saved and this is re-writabele.
 *            bssConfig : section in RAM, which is representing FConfig.
 *
 *            Application on startup shall load_bssConfig() : this will copy FConfig -> bssConfig
 *            Accessing to variables is by pointer get_pbssConfig();
 *
 *            If application wants to re-write FConfig, use save_bssConfig(*newRamParametersBlock);
 *
 *
 *            NOTE: The code is very MCU dependent and save will work with STM32F4 only
 *
 *            Linker script shall define flash sector1 ADDR_FLASH_SECTOR_1 as sections
 *
 *            ".fconfig"         @0x08004000
 *
 * @author    Decawave
 *
 * @attention Copyright 2017-2019 (c) Decawave Ltd, Dublin, Ireland.
 *            All rights reserved.
 *
 */

#include <stdint.h>
#include <string.h>
#include <stm32f4xx.h>

#include "deca_device_api.h"
#include "version.h"

#include "config.h"
#include "main.h"
//------------------------------------------------------------------------------
// the ADDR_FLASH_SECTOR_1 should be the same as .fconfig section address.
// for the
extern uint32_t __FCONFIG_START, __DEFAULT_CONFIG_START;
static param_block_t *FConfig = (param_block_t *)&__FCONFIG_START;

const param_block_t defaultFConfig __attribute__((aligned(FCONFIG_SIZE))) = DEFAULT_CONFIG;


/* run-time parameters block.
 *
 * This is the RAM image of the FConfig .
 *
 * Accessible from application by app.pConfig pointer after init_bssConfig()
 *
 * */
static param_block_t bssConfig __attribute__((section(".bss"))) __attribute__((aligned(FCONFIG_SIZE)));

extern int flash_app_erase(eFlashErase_e status);
//------------------------------------------------------------------------------

/* MACRO for WRITE
 *
 * NOTE: The code is very MCU dependent and save will work with STM32F4 only
 *
 * Linker script shall define flash sector1 as sections
 *
 * ".fconfig"         @0x08004000
 *
 * */

#define ADDR_FLASH_PAGE_2    ((uint32_t)0x08001000UL)

/*
 * (re-writable block) @ of sector 1
 *
 * must correspond to .fconfig section
 * */
#define ADDR_FLASH_PAGE_3    ((uint32_t)0x08004000UL)

#define FCONFIG_START_ADDR                ADDR_FLASH_SECTOR_1
#define FCONFIG_END_ADDR                  (ADDR_FLASH_SECTOR_1 + FCONFIG_SIZE)
#define FCONFIG_PAGES_TO_BE_PROTECTED     (OB_WRP_SECTOR_0)
///*(OB_WRP_PAGES2TO3)*/


//------------------------------------------------------------------------------
// Implementation

/*
 * @brief get pointer to run-time bss param_block_t block
 *
 * */
param_block_t *get_pbssConfig(void)
{
    return(&bssConfig);
}


/* @fn      load_bssConfig
 * @brief   copy parameters from NVM to RAM structure.
 *
 *          assumes that memory model in the MCU of .text and .bss are the same
 * */
void load_bssConfig(void)
{
    memcpy(&bssConfig, FConfig, sizeof(bssConfig));
}

/* @fn      restore_bssConfig
 * @brief   copy parameters from default NVM section to RAM structure.
 *
 *          assumes that memory model in the MCU of .text and .bss are the same
 * */
void restore_bssConfig(void)
{
    memcpy(&bssConfig, &defaultFConfig, sizeof(bssConfig));
}


/* @brief    save pNewRamParametersBlock to FConfig
 * @return  _NO_ERR for success and error_e code otherwise
 * */
error_e save_bssConfig(const param_block_t * pNewRamParametersBlock)
{
#ifdef STM32F4
//    uint32_t PageError = 0;
//    uint32_t ProtectedPages = 0x0;

//    FLASH_EraseInitTypeDef         EraseInitStruct;
    FLASH_OBProgramInitTypeDef     OptionsBytesStruct;

    uint32_t * pbuf = (uint32_t *) pNewRamParametersBlock;

    HAL_FLASH_Unlock();            /**< Unlock the Flash to enable the flash control register access */

    HAL_FLASH_OB_Unlock();        /**< Unlock the Options Bytes */

    HAL_FLASHEx_OBGetConfig(&OptionsBytesStruct);        /**< Get pages write protection status */

    /* Get pages already write protected */
//    ProtectedPages = ~(OptionsBytesStruct.WRPSector/*WRPPage*/ | FCONFIG_PAGES_TO_BE_PROTECTED);
//
//    /* Check if desired pages are already write protected */
//    if((OptionsBytesStruct.WRPSector/*WRPPage*/ | (~FCONFIG_PAGES_TO_BE_PROTECTED)) != 0xFFFFFFFF )
//    {
//        /* Erase all the option Bytes */
//        if(HAL_FLASHEx_OBErase() != HAL_OK)
//        {
//            return(_Err_Flash_Ob);    /**< Error occurred while options bytes erase */
//        }
//
//        /* Check if there is write protected pages */
//        if(ProtectedPages != 0x0)
//        {
//            /* Restore write protected pages */
//            OptionsBytesStruct.OptionType = OPTIONBYTE_WRP;
//            OptionsBytesStruct.WRPState = WRPSTATE_ENABLE;
//            OptionsBytesStruct.WRPSector/*WRPPage*/ = ProtectedPages;
//
//            if(HAL_FLASHEx_OBProgram(&OptionsBytesStruct) != HAL_OK)
//            {
//                return(_Err_Flash_Prog);    /**< Error occurred while options bytes programming. */
//            }
//        }
//
//        HAL_FLASH_OB_Launch();        /**< Generate System Reset to load the new option byte values */
//    }

    HAL_FLASH_OB_Lock();    /**< Lock the Options Bytes */

    /* The selected pages are not write protected */
    if ((OptionsBytesStruct.WRPSector/*WRPPage*/ & FCONFIG_PAGES_TO_BE_PROTECTED) != 0x00)
    {
//        /* Fill EraseInit structure */
//        EraseInitStruct.TypeErase = FLASH_TYPEERASE_SECTORS/*TYPEERASE_PAGES*/;
//        EraseInitStruct.PageAddress = FCONFIG_START_ADDR;
//        EraseInitStruct.NbPages = 1;
//
//        if (HAL_FLASHEx_Erase(&EraseInitStruct, &PageError) != HAL_OK)
//        {
//            return(_Err_Flash_Erase);    /**< Error occurred while page erase HAL_FLASH_GetError(); */
//        }

        /* FLASH the FCONFIG */
        flash_app_erase(Config_Erase);

        uint32_t Address = FCONFIG_START_ADDR;

        while (Address < FCONFIG_END_ADDR)
        {
            if (HAL_FLASH_Program(TYPEPROGRAM_WORD, Address, *pbuf) == HAL_OK)
            {
                Address += 4;
                pbuf++;
            }
            else
            {
              return(_ERR_Flash_Error);    /**< Error occurred while writing data in Flash memory */
            }
        }

        /* Check the correctness of written data */
        pbuf = (uint32_t *) pNewRamParametersBlock;
        Address = FCONFIG_START_ADDR;

        while (Address < FCONFIG_END_ADDR)
        {
            if((*(__IO uint32_t*) Address) != *pbuf)
            {
                return(_ERR_Flash_Verify);        /**< Error occurred while verifying */
            }
            Address += 4;
            pbuf++;
        }
    }
    else
    {
        return(_ERR_Flash_Protected);        /**< Error to program the flash : The desired pages are write protected */
    }

    HAL_FLASH_Lock();    /**< Lock the Flash to disable the flash control register access */
#endif
    return (_NO_ERR);
}

