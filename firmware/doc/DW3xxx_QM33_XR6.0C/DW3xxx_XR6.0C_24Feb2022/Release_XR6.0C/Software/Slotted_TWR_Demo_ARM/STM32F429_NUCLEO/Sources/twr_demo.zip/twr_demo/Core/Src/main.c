/**
 * @file      main.c
 *
 * @brief     Demo on Juniper platform.
 *
 * @author    Decawave
 *
 * @attention Copyright 2017-2019 (c) Decawave Ltd, Dublin, Ireland.
 *            All rights reserved.
 *
 */

/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2019 STMicroelectronics International N.V.
  * All rights reserved.
  *
  *
  * Redistribution and use in source and binary forms, with or without
  * modification, are permitted, provided that the following conditions are met:
  * @brief     Main file for TDOA RTLS anchor.
  *
  * 1. Redistribution of source code must retain the above copyright notice,
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other
  *    contributors to this software may be used to endorse or promote products
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under
  *    this license is void and will automatically terminate your rights under
  *    this license.
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include <cmsis_os.h>
#include <usb_device.h>

/* USER CODE BEGIN Includes */
#include <event_groups.h>

#include "crc16.h"
#include "task_usb2spi.h"
#include "node.h"
#include "task_node.h"
#include "task_tag.h"
#include "task_tcfm.h"
#include "task_tcwm.h"
#include "task_ctrl.h"
#include "task_flush.h"
#include "deca_dbg.h"
#include "deca_probe_interface.h"
#include "task_listener.h"


/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
RNG_HandleTypeDef hrng;
IWDG_HandleTypeDef hiwdg;

RTC_HandleTypeDef hrtc;
SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi5;
DMA_HandleTypeDef hdma_spi5_rx;
DMA_HandleTypeDef hdma_spi5_tx;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart3;

DMA_HandleTypeDef hdma_spi1_rx;
DMA_HandleTypeDef hdma_spi1_tx;

DMA_HandleTypeDef hdma_usart3_rx;
DMA_HandleTypeDef hdma_usart3_tx;

osThreadId defaultTaskHandle;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
gDiagPrintFStr_t  gDiagPrintFStr;
app_t   app;

static int g_network_is_up;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(int);
static void MX_USART3_UART_Init(void);
static void MX_SPI1_Init(void);
static void MX_RNG_Init(void);
void StartDefaultTask(void const * argument);
static void MX_NVIC_Init(void);
static void MX_IWDG_Init(void);
static void MX_RTC_Init(void);

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);


/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
#ifdef ENABLE_SEMIHOSTING
extern void initialise_monitor_handles(void);
#endif

extern void trilat_helper(void const *argument);
extern void trilat_terminate(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

void Restart(int status)
{
    bootloader(status);
}

#define USB_DRV_UPDATE_MS    200

int main(void)
{
    /* USER CODE BEGIN 1 */
    HAL_DBGMCU_EnableDBGSleepMode();
    HAL_DBGMCU_EnableDBGStopMode();
    HAL_DBGMCU_EnableDBGStandbyMode();

#ifdef FIRMWARE_UPGRADE
    SCB->VTOR = ADDR_FLASH_SECTOR_6;
#else
    SCB->VTOR = ADDR_FLASH_SECTOR_0;
#endif

#ifdef ENABLE_SEMIHOSTING
  initialise_monitor_handles();
  setbuf(stdout, NULL);
#endif

  init_crc16();

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */


  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_TIM3_Init(g_network_is_up);
  MX_USART3_UART_Init();
  MX_SPI1_Init();
  MX_RNG_Init();
  MX_IWDG_Init();
  MX_RTC_Init();

  /* Initialize interrupts */
  MX_NVIC_Init();

  /* USER CODE BEGIN 2 */
  HAL_IWDG_Refresh(&hiwdg);

  memset(&app, 0, sizeof(app));
  memset(&gDiagPrintFStr, 0, sizeof(gDiagPrintFStr));

  load_bssConfig();                 /**< load the RAM Configuration parameters from NVM block */
  app.pConfig = get_pbssConfig();

  app.xStartTaskEvent = xEventGroupCreate(); /**< xStartTaskEvent indicates which tasks to be started */

  /* Initialize random number generator needs for LWIP_RAND */
  uint32_t tmp;
  HAL_RNG_GenerateRandomNumber(&hrng, &tmp);
  srand(tmp);

  reset_DW3000(); //this will reset DW device


  if (dwt_probe((struct dwt_probe_s *)&dw3000_probe_interf))
  {
    error_handler(1, _ERR_INIT);
  }
  /* This initialization is added to avoid crashing the board when calling APIs that writes inside local data
  like setxtaltrim */
  if (dwt_initialise(DWT_DW_INIT) != DWT_SUCCESS)
  {
    error_handler(1, _ERR_INIT);
  }

  HAL_IWDG_Refresh(&hiwdg);

  __enable_irq();
  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */


  /* initialize inter-task communication mail queue for Node :
   *
   * The RxTask need to send the rxPckt to the CalcTask.
   *
   * TODO: rxPcktPool_q_id should be a part of NodeInfo, but
   * FreeRTOS cannot free resources efficiently on task deletion.
   *
   * Current code has an implementation where NodeInfo is statically defined
   * and rxPcktPool_q is a part of FreeRtos Heap.
   *
   * Note, the debug accumulator & diagnostics readings are a part of
   * mail queue. Every rx_mail_t has a size of ~6kB.
   *
   * */
    osMailQDef(rxPcktPool_q, RX_MAIL_QUEUE_SIZE, rx_mail_t);
    app.rxPcktPool_q_id = osMailCreate(osMailQ(rxPcktPool_q), NULL);

    if(!app.rxPcktPool_q_id)
    {
        error_handler(1, _ERR_Cannot_Alloc_Mail);
    }


  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */

  /* Note. The DefaultTask is responsible for starting & stopping of TOP Level applications. */
  osThreadDef(defaultTask, StartDefaultTask, PRIO_StartDefaultTask, 0, configMINIMAL_STACK_SIZE*2);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* FlushTask is always working and flushing the output buffer to uart/usb */
  osThreadDef(flushTask, FlushTask, PRIO_FlushTask, 0, configMINIMAL_STACK_SIZE);
  app.flushTask.Handle = osThreadCreate(osThread(flushTask), NULL);

  /* ctrlTask is always working serving rx from uart/usb */
  //2K for CTRL task: it needs a lot of memory: it uses mallocs(512), sscanf(212bytes)
  osThreadDef(ctrlTask, CtrlTask, PRIO_CtrlTask, 0, 512);
  app.ctrlTask.Handle = osThreadCreate(osThread(ctrlTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  
  if( !defaultTaskHandle | !app.flushTask.Handle | !app.ctrlTask.Handle )
  {
      error_handler(1, _ERR_Create_Task_Bad);
  }
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */


  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}



/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
    /**Configure the main internal regulator output voltage
    */
  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    /**Initializes the CPU, AHB and APB busses clocks
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE |RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 144;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
    /**Configure the Systick interrupt time
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);


  HAL_RCC_GetSysClockFreq();

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, configLIBRARY_LOWEST_INTERRUPT_PRIORITY, 0);
}

/** NVIC Configuration
*/
static void MX_NVIC_Init(void)
{
  /* USART3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(USART3_IRQn, PRIO_USART3_IRQn, 0);
  HAL_NVIC_EnableIRQ(USART3_IRQn);

  /* DMA1_Stream1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, PRIO_DMA1_Stream1_IRQn, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn); //USART3 RX

  /* DMA1_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, PRIO_DMA1_Stream3_IRQn, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn); //USART3 TX

  /* SPI1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SPI1_IRQn, PRIO_SPI1_IRQn, 0);
  HAL_NVIC_EnableIRQ(SPI1_IRQn);
  /* DMA2_Stream2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream2_IRQn, PRIO_DMA2_Stream2_IRQn, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream2_IRQn);
  /* DMA2_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream3_IRQn, PRIO_DMA2_Stream3_IRQn, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream3_IRQn);

//  /* ETH_IRQn interrupt configuration */
//  HAL_NVIC_SetPriority(ETH_IRQn, PRIO_ETH_IRQn, 0);
//  HAL_NVIC_EnableIRQ(ETH_IRQn);

  /* TIM1_CC_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM1_CC_IRQn, PRIO_TIM1_CC_IRQn, 0);
  HAL_NVIC_EnableIRQ(TIM1_CC_IRQn);
}

/* RNG init function */
static void MX_RNG_Init(void)
{

  hrng.Instance = RNG;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* RTC init function */
static void MX_RTC_Init(void)
{

  RTC_TimeTypeDef sTime;
  RTC_DateTypeDef sDate;

    /**Initialize RTC Only
    */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 1;
  hrtc.Init.SynchPrediv = 32767;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

    /**Initialize RTC and set the Time and Date
    */
  if(HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR0) != 0x32F2){
  sTime.Hours = 0x0;
  sTime.Minutes = 0x0;
  sTime.Seconds = 0x0;
  sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
  sTime.StoreOperation = RTC_STOREOPERATION_RESET;
  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }

  sDate.WeekDay = RTC_WEEKDAY_MONDAY;
  sDate.Month = RTC_MONTH_JANUARY;
  sDate.Date = 0x1;
  sDate.Year = 0x0;

  if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }

    HAL_RTCEx_BKUPWrite(&hrtc,RTC_BKP_DR0,0x32F2);
  }
    /**Enable the WakeUp
    */
  if (HAL_RTCEx_SetWakeUpTimer(&hrtc, 0, RTC_WAKEUPCLOCK_RTCCLK_DIV16) != HAL_OK)
  {
    Error_Handler();
  }

}

/* SPI1 init function */
static void MX_SPI1_Init(void)
{

  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM1 init function */
static void MX_TIM1_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_SlaveConfigTypeDef sSlaveConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig;

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV2;
  htim1.Init.RepetitionCounter = 0;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_OC_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_TRIGGER;
  sSlaveConfig.InputTrigger = TIM_TS_ITR0;
  if (HAL_TIM_SlaveConfigSynchronization(&htim1, &sSlaveConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigOC.OCMode = TIM_OCMODE_TIMING;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_OC_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim1);

}

/* USART3 init function */
static void MX_USART3_UART_Init(void)
{
    huart3.Instance = USART3;
    huart3.Init.BaudRate = 115200;
    huart3.Init.WordLength = UART_WORDLENGTH_8B;
    huart3.Init.StopBits = UART_STOPBITS_1;
    huart3.Init.Parity = UART_PARITY_NONE;
    huart3.Init.Mode = UART_MODE_TX;
    huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart3.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart3) != HAL_OK)
    {
       _Error_Handler(__FILE__, __LINE__);
    }
}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();
}

/** Configure pins as
        * Analog
        * Input
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(DW_RST_GPIO_Port, DW_RST_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD3_Pin|LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(DW_CS_GPIO_Port, DW_CS_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(DW_WUP_GPIO_Port, DW_WUP_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(USB_PowerSwitchOn_GPIO_Port, USB_PowerSwitchOn_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : USER_Btn_Pin */
  GPIO_InitStruct.Pin = USER_Btn_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(USER_Btn_GPIO_Port, &GPIO_InitStruct);


  /*Configure GPIO pin : DW_IRQ_Pin */
  GPIO_InitStruct.Pin = DW_IRQ_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(DW_IRQ_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DW_RST_Pin */
  GPIO_InitStruct.Pin = DW_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(DW_RST_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD2_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : DW_CS_Pin */
  GPIO_InitStruct.Pin = DW_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(DW_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DW_WAKEUP_Pin */
  GPIO_InitStruct.Pin = DW_WUP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
  HAL_GPIO_Init(DW_WUP_GPIO_Port, &GPIO_InitStruct);
  
//  {/* USB: disconnect DP pin */
//   /* USB: all usb pins will be initialized in the MX_USB_DEVICE_Init() -> HAL_PCD_MspInit() */
//      GPIO_InitStruct.Pin   = USB_DP_Pin;
//      GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
//      GPIO_InitStruct.Pull  = GPIO_PULLDOWN;
//      GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
//      HAL_GPIO_Init(USB_DP_GPIO_Port, &GPIO_InitStruct);
//  }

  {/* SWD: it is mandatory to configure Alternate function when the AF mode is selected */
      GPIO_InitStruct.Pin   = GPIO_PIN_13 | GPIO_PIN_14;
      GPIO_InitStruct.Mode  = GPIO_MODE_AF_PP;
      GPIO_InitStruct.Pull = GPIO_NOPULL;
      GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
      GPIO_InitStruct.Alternate = GPIO_AF0_SWJ;
      HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  }

  GPIO_InitStruct.Pin = USB_VBUS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USB_VBUS_GPIO_Port, &GPIO_InitStruct);

  /*BLUE LED Init on Anchor board*/
  GPIO_InitStruct.Pin = BLUE_LED_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(BLUE_LED_PORT, &GPIO_InitStruct);

  /*GREEN LED Init on Anchor board*/
  GPIO_InitStruct.Pin = GREEN_LED_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GREEN_LED_PORT, &GPIO_InitStruct);

  /*RED LED Init on Anchor board*/
  GPIO_InitStruct.Pin = RED_LED_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(RED_LED_PORT, &GPIO_InitStruct);

  /*USER Button on Anchor board*/
  GPIO_InitStruct.Pin = USER_BUTTON_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(USER_BUTTON_PORT, &GPIO_InitStruct);
}

static void MX_TIM3_Init(int network_status)
{
    HAL_NVIC_SetPriority(TIM3_IRQn, PRIO_TIM3_IRQn ,0);
    __HAL_RCC_TIM3_CLK_ENABLE();

    htim3.Instance = TIM3;

    htim3.Init.Period = 10000;

    if(network_status == 0)
    {
        htim3.Init.Prescaler = 540;
    }

    else if(network_status == 1)
    {
        htim3.Init.Prescaler = 2000;
    }
    htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    if(HAL_TIM_Base_Init(&htim3) == HAL_OK)
    {
      /* TIM time Base Initialisation is successful*/
    }

    HAL_NVIC_EnableIRQ(TIM3_IRQn);

    HAL_TIM_Base_Start_IT(&htim3);
}

/* USER CODE BEGIN 4 */

/* @fn         usb_vbus_driver
 * @brief     used to determine physical USB connection and
 *             start/stop USB peripheral low level driver (and IRQ)
 *
 * */
void usb_vbus_driver(void)
{
    if(HAL_GPIO_ReadPin(USB_VBUS_GPIO_Port, USB_VBUS_Pin) == GPIO_PIN_SET)
    {//USB port PLUGGED
        if (app.usbState == USB_DISCONNECTED)
        {
            MX_USB_DEVICE_Init();
            app.usbState = USB_CONNECTED;
        }
        else
        if (app.usbState == USB_CONNECTED)
        {
            if(hUsbDeviceFS.dev_state == USBD_STATE_CONFIGURED)
            {
                app.usbState = USB_CONFIGURED;
            }
            else if(hUsbDeviceFS.dev_state == USBD_STATE_SUSPENDED)
            {
                MX_USB_DEVICE_DeInit();
                app.usbState = USB_DISCONNECTED;
            }
        }
    }
    else
    {//USB port UNPLUGGED
        if (app.usbState != USB_DISCONNECTED)
        {
            MX_USB_DEVICE_DeInit();
            app.usbState = USB_DISCONNECTED;
        }
    }
}


#define BUTTON_TIME_TAG_MS (3000)
#define DEFAULT_EVENT   (Ev_Stop_All)
/* @brief
 *      no press: "default app": app, which was running on "SAVE" command
 *      if not set, then default is DEFAULT_EVENT
 *      pressed not more than 3 seconds: Tag
 *      pressed longer than 3 seconds: Node
 * */
static EventBits_t check_the_user_button(void)
{
    EventBits_t ret = DEFAULT_EVENT;

    if(HAL_GPIO_ReadPin(USER_Btn_GPIO_Port, USER_Btn_Pin) == GPIO_PIN_RESET)
    {
        if(app.pConfig->s.default_event != 0)
        {
            ret = app.pConfig->s.default_event;
        }
    }
    else
    {
        uint32_t tmr;
        start_timer(&tmr);
        bool tmp = false;

        while((HAL_GPIO_ReadPin(USER_Btn_GPIO_Port, USER_Btn_Pin) == GPIO_PIN_SET) && !(tmp = check_timer(tmr, BUTTON_TIME_TAG_MS)))
        {
            HAL_IWDG_Refresh(&hiwdg);
        }

        ret = (tmp)?(Ev_Node_Task):(Ev_Tag_Task);
    }

    return ret;
}

/* USER CODE END 4 */

/* StartDefaultTask function */
void StartDefaultTask(void const * argument)
{
    HAL_IWDG_Refresh(&hiwdg);

    /* USER CODE BEGIN 5 */

    const EventBits_t bitsWaitForAny = (Ev_Node_Task | Ev_Tag_Task | Ev_Trilat_N_Task |
                                        Ev_Usb2spi_Task | Ev_Tcwm_Task | Ev_Tcfm_Task | Ev_Listener_Task | Ev_Stop_All);

    EventBits_t    uxBits;


    uxBits = check_the_user_button();

    xEventGroupSetBits(app.xStartTaskEvent, uxBits);

    /* Infinite loop */
    while(1)
    {
        uxBits = xEventGroupWaitBits(app.xStartTaskEvent,   bitsWaitForAny,
                                                            pdTRUE, pdFALSE,
                                                            USB_DRV_UPDATE_MS/portTICK_PERIOD_MS );

      HAL_IWDG_Refresh(&hiwdg);

      uxBits &= bitsWaitForAny;

      if(uxBits)
      {
          app.lastErrorCode = _NO_ERR;

         /*   need to switch off DW chip's RX and IRQ before killing tasks */
          if(app.mode != mIDLE)
          {
              disable_dw3000_irq();
              reset_DW3000();
              app_apptimer_stop();                //cancel application slow timer
              dwt_setcallbacks(NULL, NULL, NULL, NULL, NULL, NULL, NULL);//DW_IRQ is disabled: safe to cancel all user call-backs
          }

          /* Event to start/stop task received */
          /* 1. free the resources: kill all user threads and timers */
          tag_terminate();
          node_terminate();
          usb2spi_terminate();
          tcfm_terminate();
          tcwm_terminate();
          trilat_terminate();
          listener_terminate();

          FlushTask_reset();

          app.lastErrorCode = _NO_ERR;

          //incoming Events are slow, and usually User-events, i.e. from a slow I/O,
          //however the Ev_Stop_All can be generated internally and may OR with other event,
          //because they can be received asynchronously.
          //Ev_Stop_All event should be tracked separately.
          app.mode = mIDLE;
          uxBits &= ~Ev_Stop_All;
      }

      HAL_IWDG_Refresh(&hiwdg);
      osThreadYield(); //force switch of context that the Idle task can free resources

      taskENTER_CRITICAL();

      /* 2. Start appropriate RTOS top-level application or run a usb_vbus_driver() if a dummy loop */
      switch (uxBits)
      {
      case Ev_Listener_Task:
          app.mode = mLISTENER;
          listener_helper(NULL); /* call Listener helper function which will setup sub-tasks for Listener process */
          break;

#if (PDOA_TAG == 1)
      /* PDoA */
      case Ev_Tag_Task:
          app.mode = mPTAG;
          tag_helper(NULL); /* call Tag helper function which will setup sub-tasks for Tag process */
          break;
#endif

#if (PDOA_NODE == 1)
      case Ev_Node_Task:
          app.mode = mPNODE;
          node_helper(NULL); /* call Node helper function which will setup sub-tasks for Node process */
          break;
#endif

#if (CFG_LE_TRILAT == 1)
      case Ev_Trilat_N_Task:
          app.mode = mTRILAT_N;
          trilat_helper(NULL); /* call Trilat helper function which will setup sub-tasks for Node process & Trilat */
          break;
#endif

      /* Service apps */
      case Ev_Usb2spi_Task:
          /* Setup a Usb2Spi task : 8K of stack is required to this task */
          app.mode = mUSB2SPI;
          usb2spi_helper(NULL);
          break;

      case Ev_Tcfm_Task:
          /* Setup a TCFM task */
          app.mode = mTCFM;
          tcfm_helper(NULL);    /* call tcfm helper function which will setup sub-tasks for Power test */
          break;

      case Ev_Tcwm_Task:
          /* Setup a TCWM task */
          app.mode = mTCWM;
          tcwm_helper(NULL);    /* call tcwm helper function which will setup sub-tasks for Power test */
          break;

      case Ev_Stop_All:
          app.mode = mIDLE;
        break;

      default:
          usb_vbus_driver();    /**< connection / disconnection of USB interface :
          on connection activate flush_task & usb_rx_process  */
          break;
      }

      taskEXIT_CRITICAL();    //ready to switch to a created task

    if((app.usbState == USB_CONFIGURED) && !g_network_is_up)
    {
        g_network_is_up = 1;
        HAL_TIM_Base_Stop_IT(&htim3);
        MX_TIM3_Init(g_network_is_up);
    }
    else if ((app.usbState != USB_CONFIGURED) && g_network_is_up)
    {
        g_network_is_up = 0;
        HAL_TIM_Base_Stop_IT(&htim3);
        MX_TIM3_Init(g_network_is_up);
    }
    else
    {
        ;
    }


    osThreadYield();

  }
  /* USER CODE END 5 */

}


/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
/* USER CODE BEGIN Callback 0 */

/* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }

  if(htim->Instance == TIM3) {
          HAL_GPIO_WritePin(BLUE_LED_PORT, BLUE_LED_PIN, GPIO_PIN_RESET);
            HAL_GPIO_TogglePin(GREEN_LED_PORT, GREEN_LED_PIN);
  }
/* USER CODE BEGIN Callback 1 */

/* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
    error_handler(1, _ERR_General_Error);
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/* IWDG init function */
static void MX_IWDG_Init(void)
{

  hiwdg.Instance = IWDG;
  hiwdg.Init.Prescaler = IWDG_PRESCALER_64;
  hiwdg.Init.Reload = 0x0FFF;
  if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
  {
    Error_Handler();
  }

}

/**
  * @}
  */

/**
  * @}
*/

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
