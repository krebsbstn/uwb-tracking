/**
 * @file      portDW.c
 *
 * @brief     Platform-dependent functions for current application are collected here
 *
 * @author    Decawave
 *
 * @attention Copyright 2017-2019 (c) Decawave Ltd, Dublin, Ireland.
 *            All rights reserved.
 *
 */

//#include "app.h"
#include "port.h"
#include "deca_dbg.h"

/**/
extern const dw_t *pDwChip ;
extern IWDG_HandleTypeDef hiwdg;

//-----------------------------------------------------------------------------
/*
 * The standard syscall malloc/free used in sscanf/sprintf.
 * We want them to be replaced with FreeRTOS's implementation.
 *
 * This leads that the memory allocation will be managed by FreeRTOS heap4 memory.
 * */
#ifndef _PTR
#define _PTR void *
#endif

#ifndef _VOID
#define _VOID void
#endif
_PTR _calloc_r(struct _reent *re, size_t num, size_t size)
{
    return pvPortMalloc(num*size);
}

_PTR _malloc_r(struct _reent *re, size_t size)
{
    return pvPortMalloc(size);
}

_VOID _free_r(struct _reent *re, _PTR ptr)
{
    vPortFree(ptr);
    return;
}

/***************************************************************************//*
 *
 *                               timers section
 *
 *****************************************************************************/
void
app_apptimer_delete(void)
{
    taskENTER_CRITICAL();

    if(app.appTimerHandle)
    {
        osTimerStop(app.appTimerHandle);
        app.appTimerHandle = 0;
        app.timer2Isr = NULL;
    }

    taskEXIT_CRITICAL();
}

void
app_apptimer_stop(void)
{
    taskENTER_CRITICAL();

    if(app.appTimerHandle)
    {
        osTimerStop(app.appTimerHandle);
    }

    taskEXIT_CRITICAL();
}

void*
app_apptimer_getIsr(void)
{
    return (void*)app.timer2Isr;
}

static void
appTmr_cb(void const *arg)
{
    if(app.timer2Isr)
    {
        app.timer2Isr();
    }
}

void
app_apptimer_config(uint32_t ms, void *isr)
{
    taskENTER_CRITICAL();

    if(app.appTimerHandle)
    {
        osTimerDelete(app.appTimerHandle);
    }

    app.appTimer_MS = ms;
    app.timer2Isr = isr;

    osTimerDef(appTmr, appTmr_cb);
    app.appTimerHandle  = osTimerCreate(osTimer(appTmr), osTimerOnce, NULL);

    taskEXIT_CRITICAL();
}

void
app_apptimer_start(void)
{
    if(osTimerStart(app.appTimerHandle, app.appTimer_MS/portTICK_PERIOD_MS) != osOK)
    {
        error_handler(1,_ERR_Timer_Start_Bad);
    }
}


/****************************************************************************//**
 * Sleep, usleep and bare sw_timer based on HAL tick
 */

/* @fn         start_timer(uint32_t *p_timestamp)
 * @brief     save system timestamp (in CLOCKS_PER_SEC)
 * @parm     p_timestamp pointer on current system timestamp
 */
void start_timer(volatile uint32_t * p_timestamp)
{
    *p_timestamp = HAL_GetTick();
}

/* @fn         check_timer(uint32_t timestamp , uint32_t time)
 * @brief     check if time from current timestamp over expectation
 * @param     [in] timestamp - current timestamp
 * @param     [in] time - time expectation (in CLOCKS_PER_SEC)
 * @return     true - time is over
 *             false - time is not over yet
 */
bool check_timer(uint32_t timestamp, uint32_t time)
{
    if (HAL_GetTick() - timestamp >= time)
    {
        return (true);
    }

    return (false);
}

/* @brief    Sleep
 *             -DDEBUG defined in Makefile prevents __WFI
 */
void Sleep(volatile uint32_t dwMs)
{
    uint32_t dwStart;
    start_timer(&dwStart);
    while (check_timer(dwStart, dwMs) == false)
    {
#ifndef DEBUG
//        __WFI();
#endif
    }
}

/* @fn    usleep
 * @brief precise usleep() delay
 *        We are using Data Watchpoint Register to calculate
 *        the exact number of MCU cycles per usec.
 *        The DWT is an optional block for Cortex M3/M4/M7
 * */
void usleep(uint32_t usec)
{
    uint32_t oldDEMCR;
    uint32_t iniCYCCNT;
    uint64_t cycles;

    oldDEMCR = CoreDebug->DEMCR;
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;

    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

    cycles = usec * (SystemCoreClock / 1000000);

    while (cycles > 0)
    {
        iniCYCCNT = DWT->CYCCNT;
        usec = (cycles >> 32) ? UINT32_MAX : (uint32_t) cycles;
        cycles -= usec;
        while((DWT->CYCCNT - iniCYCCNT) < usec);
    }

    CoreDebug->DEMCR = oldDEMCR;
}




/***************************************************************************//*
 *
 *                                 UART section
 *
 *****************************************************************************/

/* @fn      port_uart_rx_init()
 * @brief   UART need to know how many character needs to be received.
 *          As this is unknown, we set of reception of single character.
 *          see HAL_UART_RxCpltCallback for RX callback operation.
 * */
void port_uart_rx_init(void)
{
//    app.uartRx.head = app.uartRx.tail = 0;
//
//    if ((huart1.gState != HAL_UART_STATE_READY)
//            || (huart1.RxState != HAL_UART_STATE_READY))
//    {
//        error_handler(0, _ERR_UART_INIT);
//    }
//
//    huart1.gState = HAL_UART_STATE_READY;
//    huart1.RxState = HAL_UART_STATE_READY;
//
//    /* RX uses UART_IRQ (IT) mode; TX will use DMA_IRQ+UART_IRQ */
//    if (HAL_UART_Receive_IT(&huart1, &app.uartRx.tmpRx, 1) != HAL_OK)
//    {
//        error_handler(0, _ERR_UART_RX);
//    }
}

/* @fn      HAL_UART_RxCpltCallback
 *          ISR level function
 * @brief   on reception of UART RX char save it to the buffer.
 *          UART_RX is working in IT mode, but UART_TX is working with DMA mode
 * */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
//    uint8_t data;
//
//    data = app.uartRx.tmpRx;
//
//    /* ReStart USART RX listening for next char */
//    if (HAL_UART_Receive_IT(&huart1, &app.uartRx.tmpRx, 1) != HAL_OK)
//    {
//        error_handler(0, _ERR_UART_RxCplt);
//    }
//
//    /* Add received data to the uart Rx circular buffer */
//    if (CIRC_SPACE(app.uartRx.head, app.uartRx.tail, sizeof(app.uartRx.buf))
//            > 0)
//    {
//        app.uartRx.buf[app.uartRx.head] = data;
//        app.uartRx.head = (app.uartRx.head + 1) & (sizeof(app.uartRx.buf) - 1);
//    }
//    else
//    {
//        error_handler(0, _ERR_UART_RxCplt_Overflow);
//    }
//
//    if (app.ctrlServer.Handle)          //RTOS : ctrlTask could be not started yet
//    {
//        osSignalSet(app.ctrlServer.Handle, app.ctrlServer.Signal); //signal to the ctrl thread : UART data ready
//    }
}

/* @fn        HAL_UART_TxCpltCallback
 * @brief      on complete of UART TX release
 * */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
//    huart->gState = HAL_UART_STATE_READY;
}

/****************************************************************************//**
 *
 *                                 GPIO init section
 *
 *******************************************************************************/


/****************************************************************************//**
 *
 *                                 GPIO IRQ section
 *
 *******************************************************************************/

/* @brief     manually configuring of EXTI priority
 * */
void init_dw3000_irq(void)
{
    HAL_NVIC_SetPriority(pDwChip->irqN, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY +1 , 0);
}

void enable_dw3000_irq(void)
{
    HAL_NVIC_SetPriority(pDwChip->irqN, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY +1 , 0);
    HAL_NVIC_EnableIRQ(pDwChip->irqN);
}

void disable_dw3000_irq(void)
{
    HAL_NVIC_DisableIRQ(pDwChip->irqN);
}

__STATIC_INLINE int check_IRQ_enabled(IRQn_Type IRQn)
{
    return (( NVIC->ISER[((uint32_t)(IRQn) >> 5)]
            & (uint32_t)0x01 << (IRQn & (uint8_t)0x1F)) ? 1 : 0);
}

/* @fn         HAL_GPIO_EXTI_Callback
 * @brief      EXTI line detection callback from HAL layer
 * @param      GPIO_Pin: Specifies the port pin connected to corresponding EXTI line.
 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    switch ( GPIO_Pin )
    {
    case DW_RST_Pin :
        diag_printf("dw_rst\n");
        break;

    case DW_IRQ_Pin :
        {
            while (HAL_GPIO_ReadPin(pDwChip->irqPort, pDwChip->irqPin) == GPIO_PIN_SET)
            {
                dwt_isr();
            }

            if (app.DwCanSleepInIRQ == DW_CAN_SLEEP)
            {
                app.DwEnterSleep = DW_IS_SLEEPING_IRQ;
                dwt_entersleep(DWT_DW_IDLE_RC);   //manual sleep after successful Final TX or RX timeout
                app.DwSpiReady = DW_SPI_SLEEPING;
            }
            break;
        }

    default :
        break;
    }
}

/* @fn decamutexon()
 * @brief     historical name
 * Disables IRQ from DW IRQ lines
 * Returns the IRQ state before disable, this value is used to re-enable in decamutexoff call
 * This is called at the beginning of a critical section
 */
decaIrqStatus_t decamutexon(void)
{
    volatile decaIrqStatus_t s;

    s = check_IRQ_enabled(pDwChip->irqN);

    if (s)
    {
        HAL_NVIC_DisableIRQ(pDwChip->irqN); //disable the external interrupt line from MASTER chip IRQ
        __DSB();
        __ISB();
    }

    return s; // return state before disable, value is used to re-enable in decamutexoff call
}

/* @fn decamutexoff(s)
 * @brief (historical name)
 * restores IRQ enable state as saved by decamutexon
 * This is called at the end of a critical section
 */
void decamutexoff(decaIrqStatus_t s)
{
    if (s)
    {
        HAL_NVIC_EnableIRQ(pDwChip->irqN);
    }
}

/****************************************************************************//**
 *
 *                                 END OF IRQ section
 *
 *******************************************************************************/

/* @fn      reset_DW3000
 * @brief   DW_RESET pin on DW3000 has 2 functions
 *             In general it is output, but it also can be used to reset the DW3000 by driving this pin low.
 *             After reset, the SPI modes is set according to the SPI phase and SPI polarity IOs.
 *
 *             Note, the DW_RESET pin should not be driven high externally.
 * */
void reset_DW3000(void)
{
    const dw_t *pDw = pDwChip;
    GPIO_InitTypeDef GPIO_InitStruct;

    GPIO_InitStruct.Pin = pDw->rstPin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    HAL_GPIO_Init(pDw->rstPort, &GPIO_InitStruct);

    HAL_GPIO_WritePin(pDw->rstPort, pDw->rstPin, RESET);

    usleep(200);

    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(pDw->rstPort, &GPIO_InitStruct);

    usleep(2000);
}

/****************************************************************************//**
 *
 */



/* @fn      error_handler(block, code)
 * @brief   visually indicates something went wrong
 * @parm    if block is 1 then block execution
 * */
void error_handler(int block, error_e err)
{
    app.lastErrorCode = err;

    {
        if (block)
        {
            /* Flash Error Led*/
            while (block)
            {
                HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, GPIO_PIN_SET);
                Sleep(2000);
                HAL_IWDG_Refresh(&hiwdg);
                Sleep(3000);
                HAL_IWDG_Refresh(&hiwdg);
                Sleep(2000);
                HAL_IWDG_Refresh(&hiwdg);
                for (int i = err; i > 0; i--)
                {
                    diag_printf("Error: %d\r\n", err);
                    HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, GPIO_PIN_SET);
                    HAL_IWDG_Refresh(&hiwdg);

                    Sleep(500);
                    HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, GPIO_PIN_RESET);
                    Sleep(1000);

                }

                HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, GPIO_PIN_RESET);
                HAL_IWDG_Refresh(&hiwdg);
                Sleep(3000);
                HAL_IWDG_Refresh(&hiwdg);
                Sleep(3000);
                HAL_IWDG_Refresh(&hiwdg);
            }
        }
    }
}

__weak void wakeup_device_with_io(void)
{
    port_wakeup_dw3000_fast();
}


/* @fn      port_wakeup_dw3000_fast
 * @brief   waking up of DW3000 using DW_CS pin
 *
 *          the fast wakeup takes ~1ms:
 *          500us to hold the CS  - TODO: this time can be reduced
 *          500us to the crystal to startup
 *          + ~various time 100us...10ms
 * */
error_e port_wakeup_dw3000_fast(void)
{
    spi_handle_t *p = pDwChip->pSpi;
    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_RESET);
    usleep(500);
    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_SET);

    return _NO_ERR;
}

/* @fn      port_wakeup_dw3000
 * @brief   waking up of DW3000 using DW_CS pin
 *
 *          the fast wakeup takes ~1ms:
 *          500us to hold the CS  - TODO: this time can be reduced
 *          500us to the crystal to startup
 *          + ~various time 100us...10ms
 * */
error_e port_wakeup_dw3000(void)
{
    error_e  ret;

    spi_handle_t *p = pDwChip->pSpi;
    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_RESET);
    usleep(500);
    HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_SET);

    //it takes ~500us for crystal startup total for the DW3000 to switch to RC_IDLE 120MHz
    usleep(500);

    uint32_t cnt=0;
    // we are here on 120MHz RC
    /* Need to make sure DW IC is in IDLE_RC before proceeding */
    do
    {
        cnt++;
        if(cnt >= 5)
        {
            if(cnt == 5)
            {
                HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_RESET);
                usleep(500);
                HAL_GPIO_WritePin(p->csPort, p->csPin, GPIO_PIN_SET);
            }
            cnt++;
        }
        usleep(20);

    }while (!dwt_checkidlerc() && cnt<10);

    if (cnt >= 10)
    {
        ret = _ERR_INIT;
    }
    else
    {
        ret = _NO_ERR;
    }
    return ret;
}




/* @fn         port_stop_all_UWB(s)
 *
 * @brief     stop UWB activity
 */
void port_stop_all_UWB(void)
{
    port_disable_dw_irq_and_reset(1);
    dwt_setcallbacks(NULL, NULL, NULL, NULL, NULL, NULL, NULL);
}

/*
 * @brief disable DW_IRQ, reset DW3000
 *        and set
 *        app.DwCanSleep = DW_CANNOT_SLEEP;
 *        app.DwEnterSleep = DW_NOT_SLEEPING;
 * */
error_e port_disable_dw_irq_and_reset(int reset)
{
    taskENTER_CRITICAL();

    disable_dw3000_irq(); /**< disable NVIC IRQ until we configure the device */

    //this is called to reset the DW device
    if (reset)
    {
        reset_DW3000();
    }
    app.DwCanSleepInIRQ = DW_CANNOT_SLEEP;
    app.DwEnterSleep = DW_NOT_SLEEPING;
    app.DwSpiReady = DW_SPI_READY; //SPI ready INT not used (disabled above) here we'll assume SPI is ready

    taskEXIT_CRITICAL();

    return _NO_ERR;
}




void juniper_configure_hal_rtc_callback(void (*cb)(RTC_HandleTypeDef *))
{
    app.HAL_RTCEx_WakeUpTimerEventCb = cb;

}

void HAL_RTCEx_WakeUpTimerEventCallback(RTC_HandleTypeDef *phrtc)
{
    if(app.HAL_RTCEx_WakeUpTimerEventCb)
    {
        app.HAL_RTCEx_WakeUpTimerEventCb(phrtc);
    }
}


/**/

#if (configCHECK_FOR_STACK_OVERFLOW > 0)

void vApplicationStackOverflowHook( TaskHandle_t xTask, char *pcTaskName )
{
    diag_printf("Task OverFlow: %s : 0x%lx\n", pcTaskName, (uint32_t)xTask);
    error_handler(1, _ERR_Stack_Overflow);
}
#endif
/* END of portDW.c */
